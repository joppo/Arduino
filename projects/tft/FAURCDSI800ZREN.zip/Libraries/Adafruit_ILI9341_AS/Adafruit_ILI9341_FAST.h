// Uncomment next #define for ATmega328, the routines then use direct PORTB access
// Comment out the #define for other processors (32u4, ATmega2560 etc)!

//#define F_AS_T
